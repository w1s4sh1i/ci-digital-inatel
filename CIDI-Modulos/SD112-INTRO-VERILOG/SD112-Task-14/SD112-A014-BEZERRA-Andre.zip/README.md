# Atividade A-014 / SD-112

> Conteúdo descritivo e analítico

:white_check_mark:


- 


​:white_check_mark: 


## Executar

> 

### GTKwave

```
$ vvp <file>

$ gtkwave <file>.vcd
```

### ModelSim

> 

```
$ do execute-task.do
```

## Fluxograma

![]()

## Results

![]()
